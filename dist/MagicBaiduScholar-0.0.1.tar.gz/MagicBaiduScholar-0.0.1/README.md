# MagicBaiduScholar

Baidu Scholar search API. This is a brother project with [MagicCNKI](https://github.com/1049451037/MagicCNKI).

# Requirement

* Python 3

# Installation

```shell
pip install MagicBaiduScholar
```

# Usage

See or run test.py

# Todo

Actually, Baidu Scholar has many data to crawl such as users and journals. I will complement it later.